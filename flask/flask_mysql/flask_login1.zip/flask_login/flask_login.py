from flask import Flask, render_template, request, redirect, flash,session
from mysqlconnection import connectToMySQL
import re
from flask_bcrypt import Bcrypt       
# from flask.ext.bcrypt import Bcrypt



db="flask_ulogin"
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key = 'keep it secret, keep it safe' 

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/register', methods=['POST'])
def register():
    print("I am in register")

    myconn = connectToMySQL(db)
    querry = "select email from users where email = %(email)s;"
    print(querry)
    print(request.form)
    data = {  
        'email' : request.form['email'],
    }
    myselect = myconn.query_db(querry,data)
    print(myselect)
    if myselect:
        flash("You already registered")
        return redirect ('/')

    if not EMAIL_REGEX.match(request.form['email']):  
        flash("Invalid email address!")
    if len(request.form['fname']) < 1:
        flash("Please enter a first name")
    if len(request.form['lname']) < 1:
        flash("Please enter a last name")
    if request.form['password'] != request.form['vpassword']:
        flash("Password does not match!")

    if not '_flashes' in session.keys():	# no flash messages means all validations passed
        # add user to database
       
        pw_hash = bcrypt.generate_password_hash(request.form['password'])  
        print(pw_hash) 
        myconn = connectToMySQL(db)
        querry = "insert into users(fname,lname, email, password) VALUES(%(fname)s,%(lname)s, %(email)s, %(password)s);"
        print(querry)
        print(request.form)
        data = {
            'fname' : request.form['fname'],
            'lname' : request.form['lname'],
            'email' : request.form['email'],
            'password': pw_hash 
        }

        myinsert = myconn.query_db(querry,data)
        if (myinsert):
             flash("You successfully registered!")

        return redirect ('/')
    else:
        return redirect ('/')

@app.route('/login', methods=['POST'])
def login():
    mysql = connectToMySQL(db)
    query = "SELECT * FROM users WHERE email = %(userid)s;"
    data = { "userid" : request.form["userid"] }
    result = mysql.query_db(query, data)
    if len(result) > 0:
        # assuming we only have one user with this username, the user would be first in the list we get back
        # of course, we should have some logic to prevent duplicates of usernames when we create users
        # use bcrypt's check_password_hash method, passing the hash from our database and the password from the form
        if bcrypt.check_password_hash(result[0]['password'], request.form['password']):
            # if we get True after checking the password, we may put the user id in session
            session['user_name'] = result[0]['id']
            # never render on a post, always redirect!
            return redirect('/success')
    # if we didn't find anything in the database by searching by username or if the passwords don't match,
    # flash an error message and redirect back to a safe route
    flash("You could not be logged in")
    return redirect("/")

@app.route('/success')
def success():
    if 'user_name' in session:
        return render_template('success.html')
    else:
        return redirect ("/")

@app.route('/logout')
def logout():
    session.clear()  
    return redirect('/')

if __name__ == '__main__':
    app.run( debug = True)