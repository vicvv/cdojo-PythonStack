from django.apps import AppConfig


class MyTimeDisplayConfig(AppConfig):
    name = 'my_time_display'
