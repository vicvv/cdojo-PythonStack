from django.apps import AppConfig


class ShowAppConfig(AppConfig):
    name = 'show_app'
