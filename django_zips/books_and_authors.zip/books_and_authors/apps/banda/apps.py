from django.apps import AppConfig


class BandaConfig(AppConfig):
    name = 'banda'
