
// $(function () {
//     $('#datetimepicker1').datetimepicker();
// });

$.noConflict();
jQuery(document).ready(function ($) {
    $('#datetimepicker1').datetime();
});
