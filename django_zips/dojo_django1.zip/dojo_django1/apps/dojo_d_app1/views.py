from django.shortcuts import render, HttpResponse, redirect
def index(request):
    return HttpResponse('skdfjlskfjlsdkfj lskfjslfkjlskfjsldkfj')

# def some_method(request):
# 	return redirect ('/')
