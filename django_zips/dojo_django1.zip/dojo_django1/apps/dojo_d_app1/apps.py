from django.apps import AppConfig


class DojoDApp1Config(AppConfig):
    name = 'dojo_d_app1'
