from django.apps import AppConfig


class MyfbooksConfig(AppConfig):
    name = 'myfbooks'
