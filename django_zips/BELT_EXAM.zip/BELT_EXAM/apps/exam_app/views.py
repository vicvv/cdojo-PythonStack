from django.shortcuts import render
from django.shortcuts import render, redirect,reverse
from django.http import HttpResponseRedirect
from django.db.models import Q
from django.contrib import messages

from . models import *

def index(request):    
    return redirect ('/home')

def about(request):
    return render (request, 'exam_app/about.html')

def home(request):
    if 'id' in request.session:
        alljobs = Job.objects.all()
        myjobs = Job.objects.filter(participant=request.session['id'])    
        context = {
            "alljobs" : alljobs,
            "myjobs" : myjobs,       
        }  
        return render (request, 'exam_app/home.html', context)
    else:
        messages.add_message(request, messages.ERROR, "You have to log in first.")
        return redirect ("/logmein/login")

def addnewjob(request):
    #if user tries to view page but has not logged in and created a request.session['id'] redirect to login and registration page with error message
    if 'id' not in request.session:
        messages.add_message(request, messages.ERROR, "You have to log in first.")
        return redirect ("/logmein/login")
    return render(request, 'exam_app/addnewjob.html')

def addjobform(request):
   #if there are errors add errors to messages and redirect to the 'add a jobs' page
    errors = Job.objects.jobs_validation(request.POST)
    if len(errors) > 0:
        for key, error in errors.items():
            messages.error(request, key, error)
            print (key, error)
        return redirect('/home/addnewjob')
    #if there are no errors then create an object in the jobs table  
    # and link creator to the logged in user
    else:
        Job.objects.create(
            title=request.POST['title'], \
            description=request.POST['description'],  \
            location= request.POST['location'], \
            creator=MyUser.objects.get(id=request.session['id'])  ,\
            category1 = request.POST['category1'], \
            category2 = request.POST['category2'], \
            category3 = request.POST['category3'], \
            category4 = request.POST['category4'],            
            )
        return redirect('/home')

def view_jobs(request, job_id):
    #if user tries to view page but has not logged in and created a request.session['id'] redirect to login and registration page with error message
    if 'id' not in request.session:
        messages.add_message(request, messages.ERROR, "You have to log in first.")
        return redirect ("/logmein/login")
    #get the information for the jobs where the id is the id of the jobs that was clicked

    job = Job.objects.get(id=job_id)
    user = MyUser.objects.get(id=request.session['id'])
    context = {
        'job': job,
        'users' : user
    }
    return render(request, 'exam_app/viewjob.html', context)


def edit_job(request, job_id):
    if 'id' not in request.session:
        messages.add_message(request, messages.ERROR, "You have to log in first.")
        return redirect ("/logmein/login")

    
    #get the information for the jobs where the id is the id of the jobs that was clicked
    context = {
        'job': Job.objects.get(id=job_id)
    }
    return render(request, 'exam_app/editjob.html', context)

def edit_job_form(request, job_id):
    job = Job.objects.get(id=job_id)
    if 'id' in request.session:
        errors = Job.objects.jobs_validation(request.POST)
        if len(errors) > 0:
            for tag, error in errors.items():
                messages.error(request, error)
            return redirect('/home/' + str(job_id) +'/edit_job')
        
        job.title = request.POST['title'] 
        job.description = request.POST['description']
        job.location = request.POST['location'] 
        job.save()

        # book.update(title = request.POST['title'])
        # book.update(description = request.POST['description'])
        messages.add_message(request, messages.INFO, "The book edit was successful")   
        return redirect ('/home')
    else:
        messages.add_message(request, messages.ERROR, "You have to log in first.")
        return redirect ("/logmein/login")

def deletejob(request, job_id):
    Job.objects.filter(id=job_id).delete()
    return  redirect ('/home')


def join_jobs(request, job_id):
    job = Job.objects.get(id=job_id)
    user = MyUser.objects.get(id=request.session['id'])
    job.participant = MyUser.objects.get(id=request.session['id'])
    job.save()
    return redirect('/home')

def give_jobs(request, job_id):
    job = Job.objects.get(id=job_id)
    job.participant = None
    job.save()
    return redirect('/home')