from django.conf.urls import url,include
from django.contrib import admin
from  .  import views

urlpatterns = [
    url(r'^$', views.index),   
    url(r'^home$', views.home, name = "home"),
    url(r'^home/about$', views.about, name = 'about'),
    url(r'^home/addnewjob$', views.addnewjob, name = 'addnewjob'),
    url(r'^home/addnewjob/addjobform$', views.addjobform),
    url(r'^home/(?P<job_id>\d+)/view$', views.view_jobs, name = 'view'),
    url(r'^home/(?P<job_id>\d+)/edit_job$', views.edit_job, name = 'edit'),
    url(r'^home/(?P<job_id>\d+)/edit_job/edit_job_form$', views.edit_job_form),
    url(r'^home/(?P<job_id>\d+)/delete$', views.deletejob, name= 'delete'),
    url(r'^home/(?P<job_id>\d+)/join', views.join_jobs, name = 'join'),
    url(r'^home/(?P<job_id>\d+)/giveup', views.give_jobs, name = 'giveup'),

    # url(r'^home/newpost$', views.newpost, name = 'newpost'),
    # url(r'^home/newcomentform$', views.newcomentform,),
    # url(r'^home/newpost/newpostform$', views.newpostform ),

    # url(r'^home/(?P<post_id>\d+)/editpost$', views.editpost, name = 'edit'),    
    # url(r'^home/(?P<post_id>\d+)/editpost/editpostform$',views.editpostform),
    # url(r'^home/(?P<post_id>\d+)/delete$', views.deletemessage, name= 'delete'),   
]



# from django.conf.urls import url
# from . import views
# urlpatterns = [
#     url(r'^$', views.index),
#     url(r'add$', views.add),
#     url(r'add_jobs$', views.add_jobs),
#     url(r'destination/(?P<number>\d+)$', views.view_jobs),
#     url(r'join_jobs/(?P<number>\d+)$', views.join_jobs)
# ]
