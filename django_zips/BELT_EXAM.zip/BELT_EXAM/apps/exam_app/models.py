from django.db import models
from datetime import date, datetime
from .. login_app.models import MyUser


class jobsManager(models.Manager):
    def jobs_validation(self, postData):
        errors = {}
        # check if the description field is empty
        if len(postData['title']) < 1:
            errors['title'] = "Please enter a title."
        # check if the description field is empty
        if len(postData['description']) < 1:
            errors['description'] = "Please enter a description."
        #check if the location field is empty
        if len(postData['location']) < 1:
            errors['location'] = "Please enter a description."

        return errors
class Job(models.Model):
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    category1 = models.CharField(max_length=255, blank=True, null=True)
    category2 = models.CharField(max_length=255, blank=True, null=True)
    category3 = models.CharField(max_length=255, blank=True, null=True)
    category4 = models.CharField(max_length=255, blank=True, null=True)
    creator = models.ForeignKey(MyUser, related_name = "jobss_creator",on_delete=models.CASCADE)
    participant = models.ForeignKey(MyUser, blank=True, null=True)
    #participant = models.IntegerField(blank=True, null=True)
    #participants = models.ManyToManyField(MyUser, related_name = "jobss_participants")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = jobsManager()



